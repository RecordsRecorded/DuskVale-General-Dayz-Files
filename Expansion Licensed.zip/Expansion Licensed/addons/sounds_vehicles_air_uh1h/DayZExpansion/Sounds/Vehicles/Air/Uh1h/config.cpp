////////////////////////////////////////////////////////////////////
//DeRap: config.bin
//Produced from mikero's Dos Tools Dll version 10.14
//https://mikero.bytex.digital/Downloads
//'now' is Fri Jul 03 20:31:05 2026 : 'file' last modified on Tue Apr 07 14:44:31 2026
////////////////////////////////////////////////////////////////////

#define _ARMA_

class CfgPatches
{
	class DayZExpansion_Sounds_Vehicles_Air_Uh1h
	{
		units[] = {};
		weapons[] = {};
		requiredVersion = 0.1;
		requiredAddons[] = {"DZ_Sounds_Effects"};
	};
};
class CfgSoundShaders
{
	class baseCharacter_SoundShader;
	class baseVehicles_SoundShader;
	class Expansion_Uh1h_Base_Int_SoundShader
	{
		range = 2000;
	};
	class Expansion_Uh1h_Base_Ext_SoundShader
	{
		range = 2000;
	};
	class Expansion_Uh1h_Engine_Int_SoundShader: Expansion_Uh1h_Base_Int_SoundShader
	{
		samples[] = {{"DayZExpansion\Sounds\Vehicles\Air\Uh1h\Expansion_Uh1h_Engine_Int",1}};
		frequency = "rpm";
		volume = "rpm * (1 - camPos) * 0.4";
	};
	class Expansion_Uh1h_Engine_Ext_SoundShader: Expansion_Uh1h_Base_Ext_SoundShader
	{
		samples[] = {{"DayZExpansion\Sounds\Vehicles\Air\Uh1h\Expansion_Uh1h_Engine_Ext",1}};
		frequency = "rpm";
		volume = "rpm * ((1 - 0.25*doors) max campos) * (1 - 0.2 * (1 - campos))";
	};
	class Expansion_Uh1h_Rotor_Int_SoundShader: Expansion_Uh1h_Base_Int_SoundShader
	{
		samples[] = {{"DayZExpansion\Sounds\Vehicles\Air\Uh1h\Expansion_Uh1h_Rotor_Int",1}};
		frequency = "speed - 0.05 * (speed factor[0, 0.95]) * (speed factor[1, 0.95])";
		volume = "(speed factor[0.2, 0.65]) * (1 - camPos) * 0.3";
	};
	class Expansion_Uh1h_Rotor_Ext_SoundShader: Expansion_Uh1h_Base_Ext_SoundShader
	{
		samples[] = {{"DayZExpansion\Sounds\Vehicles\Air\Uh1h\Expansion_Uh1h_Rotor_Ext",1}};
		frequency = "speed - 0.05 * (speed factor[0, 0.95]) * (speed factor[1, 0.95])";
		volume = "(speed factor[0.2, 0.65]) * ((1 - 0.25*doors) max campos) * (1 - 0.2 * (1 - campos))";
	};
	class Expansion_Uh1h_Engine_Full_Int_SoundShader: Expansion_Uh1h_Base_Int_SoundShader
	{
		samples[] = {{"DayZExpansion\Sounds\Vehicles\Air\Uh1h\Expansion_Uh1h_Engine_Int",1}};
		frequency = "0.3+(0.5*speed)+(0.2*(rpm factor[800, 5000]))";
		volume = "(1-camPos)*(rpm factor [800, 4600])";
	};
	class Expansion_Uh1h_Engine_Full_Ext_SoundShader: Expansion_Uh1h_Base_Ext_SoundShader
	{
		samples[] = {{"DayZExpansion\Sounds\Vehicles\Air\Uh1h\Expansion_Uh1h_Engine_Ext",1}};
		frequency = "0.3+(0.5*speed)+(0.2*(rpm factor[800, 5000]))";
		volume = "(rpm factor [800, 4600]) * ((1 - 0.25*doors) max campos) * (1 - 0.2 * (1 - campos))";
		range = 1500;
	};
	class Expansion_Uh1h_Rotor_Starter_Int_SoundShader: Expansion_Uh1h_Base_Int_SoundShader
	{
		samples[] = {{"DayZExpansion\Sounds\Vehicles\Air\Bell412\medium-rotor-int-starter3",1}};
		frequency = "0.25 + (0.25*(speed factor[0.05, 0.15]))";
		volume = "(1-camPos)*(speed factor [0.01, 0.3]) * (speed factor[0.6, 0.3])";
	};
	class Expansion_Uh1h_Rotor_Full_Int_SoundShader: Expansion_Uh1h_Base_Int_SoundShader
	{
		samples[] = {{"DayZExpansion\Sounds\Vehicles\Air\Uh1h\Expansion_Uh1h_Rotor_Int",1}};
		frequency = "speed - 0.05 * (speed factor[0, 0.95]) * (speed factor[1, 0.95])";
		volume = "(1-camPos)*(speed factor [0.2, 0.85]) * 0.9";
	};
	class Expansion_Uh1h_Rotor_Starter_Ext_SoundShader: Expansion_Uh1h_Base_Ext_SoundShader
	{
		samples[] = {{"DayZExpansion\Sounds\Vehicles\Air\Bell412\medium-rotor-ext-starter3",1}};
		frequency = "0.25 + (0.25*(speed factor[0.05, 0.2]))";
		volume = "(speed factor [0.01, 0.3]) * (speed factor[0.6, 0.3]) * ((1 - 0.25*doors) max campos) * (1 - 0.2 * (1 - campos))";
		range = 1200;
	};
	class Expansion_Uh1h_Rotor_Full_Ext_SoundShader: Expansion_Uh1h_Base_Ext_SoundShader
	{
		samples[] = {{"DayZExpansion\Sounds\Vehicles\Air\Uh1h\Expansion_Uh1h_Rotor_Ext",1}};
		frequency = "speed - 0.05 * (speed factor[0, 0.95]) * (speed factor[1, 0.95])";
		volume = "(speed factor [0.2, 0.85]) * ((1 - 0.25*doors) max campos) * (1 - 0.2 * (1 - campos))";
	};
	class Expansion_Uh1h_SlidingDoor_Open_SoundShader: baseVehicles_SoundShader
	{
		samples[] = {{"\DZ\sounds\environment\buildings\doors\WoodSlideBig\doorWoodSlideBigOpen_2",1}};
		volume = 0.9;
	};
	class Expansion_Uh1h_SlidingDoor_Close_SoundShader: baseVehicles_SoundShader
	{
		samples[] = {{"\DZ\sounds\environment\buildings\doors\WoodSlide\doorWoodSlideClose_4",1}};
		volume = 0.9;
	};
	class Expansion_Uh1h_Starter_Start_Int_SoundShader: Expansion_Uh1h_Base_Int_SoundShader
	{
		samples[] = {{"DayZExpansion\Sounds\Vehicles\Air\Bell412\medium_int_starter_start",1}};
		frequency = 1;
		volume = 1;
	};
	class Expansion_Uh1h_Starter_Start_Ext_SoundShader: Expansion_Uh1h_Base_Ext_SoundShader
	{
		samples[] = {{"DayZExpansion\Sounds\Vehicles\Air\Bell412\medium_ext_starter_start",1}};
		frequency = 1;
		volume = 1;
		range = 200;
	};
	class Expansion_Uh1h_Starter_Stop_Int_SoundShader: Expansion_Uh1h_Base_Int_SoundShader
	{
		samples[] = {{"DayZExpansion\Sounds\Vehicles\Air\Bell412\medium_int_starter_stop",1}};
		frequency = 1;
		volume = 1;
	};
	class Expansion_Uh1h_Starter_Stop_Ext_SoundShader: Expansion_Uh1h_Base_Ext_SoundShader
	{
		samples[] = {{"DayZExpansion\Sounds\Vehicles\Air\Bell412\medium_ext_starter_stop",1}};
		frequency = 1;
		volume = 1;
		range = 200;
	};
	class Expansion_Uh1h_Engine_Idle_Start_Int_SoundShader: Expansion_Uh1h_Base_Int_SoundShader
	{
		samples[] = {{"DayZExpansion\Sounds\Vehicles\Air\Bell412\medium_int_idle_start",1}};
		frequency = 1;
		volume = 0.3;
	};
	class Expansion_Uh1h_Engine_Idle_Start_Ext_SoundShader: Expansion_Uh1h_Base_Ext_SoundShader
	{
		samples[] = {{"DayZExpansion\Sounds\Vehicles\Air\Bell412\medium_ext_idle_start",1}};
		frequency = 1;
		volume = 0.3;
		range = 600;
	};
	class Expansion_Uh1h_Warning_SoundShader: baseVehicles_SoundShader
	{
		samples[] = {{"DayZExpansion\Sounds\Vehicles\Air\Bell412\warning",1}};
		frequency = 1;
		volume = 0.9;
		range = 35;
	};
};
class CfgSoundSets
{
	class baseCharacter_SoundSet;
	class baseVehicles_SoundSet;
	class Expansion_Uh1h_Base_Ext_SoundSet
	{
		sound3DProcessingType = "Vehicle_Ext_3DProcessingType";
		distanceFilter = "softVehiclesDistanceFreqAttenuationFilter";
		volumeCurve = "vehicleEngineAttenuationCurve";
		volumeFactor = 1;
		occlusionFactor = 0;
		obstructionFactor = 0;
		spatial = 1;
		loop = 1;
		positionOffset[] = {0,0,0};
	};
	class Expansion_Uh1h_Base_Int_SoundSet
	{
		sound3DProcessingType = "Vehicle_Int_3DProcessingType";
		distanceFilter = "softVehiclesDistanceFreqAttenuationFilter";
		volumeCurve = "vehicleEngineAttenuationCurve";
		volumeFactor = 1;
		occlusionFactor = 0;
		obstructionFactor = 0;
		spatial = 1;
		loop = 1;
		positionOffset[] = {0,0,0};
	};
	class Expansion_Uh1h_Engine_Int_SoundSet: Expansion_Uh1h_Base_Int_SoundSet
	{
		soundShaders[] = {"Expansion_Uh1h_Engine_Int_SoundShader"};
		volumeFactor = 1;
	};
	class Expansion_Uh1h_Engine_Ext_SoundSet: Expansion_Uh1h_Base_Ext_SoundSet
	{
		soundShaders[] = {"Expansion_Uh1h_Engine_Ext_SoundShader"};
		volumeFactor = 1;
	};
	class Expansion_Uh1h_Rotor_Int_SoundSet: Expansion_Uh1h_Base_Int_SoundSet
	{
		soundShaders[] = {"Expansion_Uh1h_Rotor_Int_SoundShader"};
		volumeFactor = 1;
	};
	class Expansion_Uh1h_Rotor_Ext_SoundSet: Expansion_Uh1h_Base_Ext_SoundSet
	{
		soundShaders[] = {"Expansion_Uh1h_Rotor_Ext_SoundShader"};
		volumeFactor = 1;
	};
	class Expansion_Uh1h_Engine_Full_Int_SoundSet: Expansion_Uh1h_Base_Int_SoundSet
	{
		soundShaders[] = {"Expansion_Uh1h_Engine_Full_Int_SoundShader"};
		volumeFactor = 0.4;
	};
	class Expansion_Uh1h_Engine_Full_Ext_SoundSet: Expansion_Uh1h_Base_Ext_SoundSet
	{
		soundShaders[] = {"Expansion_Uh1h_Engine_Full_Ext_SoundShader"};
		volumeFactor = 1;
	};
	class Expansion_Uh1h_Rotor_Starter_Int_SoundSet: Expansion_Uh1h_Base_Int_SoundSet
	{
		soundShaders[] = {"Expansion_Uh1h_Rotor_Starter_Int_SoundShader"};
		volumeFactor = 0.25;
	};
	class Expansion_Uh1h_Rotor_Full_Int_SoundSet: Expansion_Uh1h_Base_Int_SoundSet
	{
		soundShaders[] = {"Expansion_Uh1h_Rotor_Full_Int_SoundShader"};
		volumeFactor = 0.3;
	};
	class Expansion_Uh1h_Rotor_Starter_Ext_SoundSet: Expansion_Uh1h_Base_Ext_SoundSet
	{
		soundShaders[] = {"Expansion_Uh1h_Rotor_Starter_Ext_SoundShader"};
		volumeFactor = 0.6;
	};
	class Expansion_Uh1h_Rotor_Full_Ext_SoundSet: Expansion_Uh1h_Base_Ext_SoundSet
	{
		soundShaders[] = {"Expansion_Uh1h_Rotor_Full_Ext_SoundShader"};
		volumeFactor = 1;
	};
	class Expansion_Uh1h_SlidingDoor_Open_SoundSet: baseVehicles_SoundSet
	{
		soundShaders[] = {"Expansion_Uh1h_SlidingDoor_Open_SoundShader"};
	};
	class Expansion_Uh1h_SlidingDoor_Close_SoundSet: baseVehicles_SoundSet
	{
		soundShaders[] = {"Expansion_Uh1h_SlidingDoor_Close_SoundShader"};
	};
	class Expansion_Uh1h_Starter_Start_Int_SoundSet: Expansion_Uh1h_Base_Int_SoundSet
	{
		loop = 0;
		soundShaders[] = {"Expansion_Uh1h_Starter_Start_Int_SoundShader"};
		volumeFactor = 1;
	};
	class Expansion_Uh1h_Starter_Start_Ext_SoundSet: Expansion_Uh1h_Base_Ext_SoundSet
	{
		loop = 0;
		soundShaders[] = {"Expansion_Uh1h_Starter_Start_Ext_SoundShader"};
		volumeFactor = 1;
	};
	class Expansion_Uh1h_Starter_Stop_Int_SoundSet: Expansion_Uh1h_Base_Int_SoundSet
	{
		loop = 0;
		soundShaders[] = {"Expansion_Uh1h_Starter_Stop_Int_SoundShader"};
		volumeFactor = 1;
	};
	class Expansion_Uh1h_Starter_Stop_Ext_SoundSet: Expansion_Uh1h_Base_Ext_SoundSet
	{
		loop = 0;
		soundShaders[] = {"Expansion_Uh1h_Starter_Stop_Ext_SoundShader"};
		volumeFactor = 1;
	};
	class Expansion_Uh1h_Engine_Idle_Start_Int_SoundSet: Expansion_Uh1h_Base_Int_SoundSet
	{
		loop = 0;
		soundShaders[] = {"Expansion_Uh1h_Engine_Idle_Start_Int_SoundShader"};
		volumeFactor = 1;
	};
	class Expansion_Uh1h_Engine_Idle_Start_Ext_SoundSet: Expansion_Uh1h_Base_Ext_SoundSet
	{
		loop = 0;
		soundShaders[] = {"Expansion_Uh1h_Engine_Idle_Start_Ext_SoundShader"};
		volumeFactor = 1;
	};
	class Expansion_Uh1h_Warning_SoundSet: baseVehicles_SoundSet
	{
		loop = 0;
		soundShaders[] = {"Expansion_Uh1h_Warning_SoundShader"};
		volumeFactor = 1;
	};
};
