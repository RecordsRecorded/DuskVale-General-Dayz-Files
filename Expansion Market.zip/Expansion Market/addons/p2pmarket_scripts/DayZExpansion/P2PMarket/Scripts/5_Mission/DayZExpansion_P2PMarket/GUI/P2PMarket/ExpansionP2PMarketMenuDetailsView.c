/**
 * ExpansionP2PMarketMenuDetailsView.c
 *
 * DayZ Expansion Mod
 * www.dayzexpansion.com
 * © 2025 DayZ Expansion Mod Team
 *
 * This work is licensed under the Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License.
 * To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-nd/4.0/.
 *
*/

class ExpansionP2PMarketMenuDetailsView: ExpansionP2PMarketMenuViewBase
{
	protected ref ExpansionP2PMarketMenuDetailsViewController m_P2PMarketMenuDetailsController;
	protected ExpansionP2PMarketMenu m_P2PMarketMenu;
	protected ExpansionP2PMarketSettings m_P2PMarketSettings;
	
	protected ref ExpansionMarketMenuTooltip m_MarketPriceTooltip;
	protected ref ExpansionP2PMarketMenuItemTooltip m_InfoTooltip;

	protected ImageWidget health_image;
	protected Widget item_quantity;
	protected Widget quantity_bar_panel;
	protected ProgressBarWidget quantity_bar;
	protected TextWidget quantity_value;
	protected Widget quantity_color;
	protected Widget item_liquid;
	protected Widget liquid_color;
	protected Widget item_cargo_count;
	protected Widget item_attachments_count;
	protected Widget item_foodstate;
	protected Widget foodstate_color;
#ifdef EXPANSIONMODHARDLINE
	protected Widget item_rarity;
	protected Widget rarity_color;
	protected TextWidget rarity_value;
#endif

	protected int m_ListPrice;
	protected int m_ListCost;

	protected EditBoxWidget listing_price_editbox;
	protected TextWidget price_text;
	protected Widget listing_cost_panel;
	
	protected Widget listing_lowest_panel;
	protected Widget listing_highest_panel;
	protected Widget listing_market_panel;

	protected ButtonWidget back_button;
	protected TextWidget back_button_text;

	protected GridSpacerWidget confirm_button_panel;
	protected ButtonWidget confirm_button;
	protected TextWidget confirm_button_text;

	protected ItemPreviewWidget view_item_preview;
	protected PlayerPreviewWidget view_player_preview;

	Object m_CurrentPreviewObject;
	ref ExpansionPlayerPreview m_PlayerPreview;
	protected vector m_CharacterOrientation;
	protected int m_CharacterRotationX;
	protected int m_CharacterRotationY;
	protected int m_CharacterScaleDelta;

	protected TextWidget info_title;
	protected GridSpacerWidget info_grid;
	protected RichTextWidget item_description;
	protected Widget info_content;
	protected ButtonWidget info_button;
	
	protected ScrollWidget item_details_attachments_scroller;
	protected ScrollWidget item_details_cargo_scroller;

	void ExpansionP2PMarketMenuDetailsView(ExpansionP2PMarketMenu menu)
	{
		Class.CastTo(m_P2PMarketMenuDetailsController, GetController());

		m_P2PMarketMenu = menu;
		m_P2PMarketSettings = GetExpansionSettings().GetP2PMarket();
		
		if (GetExpansionSettings().GetMarket().MarketSystemEnabled)
		{
			m_MarketPriceTooltip = new ExpansionMarketMenuTooltip();
			m_MarketPriceTooltip.SetContentOffset(-0.234375, 0.006944);
			m_MarketPriceTooltip.AddEntry("#STR_EXPANSION_MARKET_P2P_MARKET_TOOLTIP_DESC");
		}
		
		m_PlayerPreview = new ExpansionPlayerPreview(this, view_player_preview);
	}
	
	void ~ExpansionP2PMarketMenuDetailsView()
	{
		if (m_PlayerPreview)
			m_PlayerPreview = null;
		
		if (m_MarketPriceTooltip)
			m_MarketPriceTooltip.Destroy();
		
		if (m_InfoTooltip)
			m_InfoTooltip.Destroy();
	}
	
	void UpdateItemInfoTooltip(ExpansionP2PMarketListingBase listing)
	{
		m_InfoTooltip = new ExpansionP2PMarketMenuItemTooltip(this);
		m_InfoTooltip.Hide();
		m_InfoTooltip.SetListing(listing);
	}

	override string GetLayoutFile()
	{
		return "DayZExpansion/P2PMarket/GUI/layouts/expansion_p2pmarket_menu_details_view.layout";
	}

	override typename GetControllerType()
	{
		return ExpansionP2PMarketMenuDetailsViewController;
	}

	private bool UsePlayerPreview()
	{
		if (m_P2PMarketMenu.GetSelectedPreviewObject())
			return m_P2PMarketMenu.GetSelectedPreviewObject().IsInherited(Clothing_Base);
		return false;
	}

	//! This method allows mods to override GetPreviewClassName while still keeping the original code in one place
	string GetPreviewClassName(string className, bool ignoreBaseBuildingKits = false)
	{
		return m_P2PMarketMenu.GetPreviewClassName(className, ignoreBaseBuildingKits);
	}

	void SpawnAttachments(array<ref ExpansionP2PMarketContainerItem> attachments, EntityAI parent, int skinIndex = 0)
	{
		foreach (ExpansionP2PMarketContainerItem attachment: attachments)
		{
			string attachmentName = attachment.GetClassName();
			ExpansionItemSpawnHelper.SpawnAttachment(attachmentName, parent, skinIndex);
		}
	}

	void UpdateScale(int mouse_x, int mouse_y, bool is_dragging, int wheel)
	{
		float w, h, x, y;
		view_item_preview.GetPos(x, y);
		view_item_preview.GetSize(w,h);
		w = w + (m_CharacterScaleDelta / 4);
		h = h + (m_CharacterScaleDelta / 4);
		if ( w > 0.5 && w < 4 )
		{
			view_item_preview.SetSize(w, h);

			// align to center
			int screen_w, screen_h;
			GetScreenSize(screen_w, screen_h);
			float new_x = x - (m_CharacterScaleDelta / 8);
			float new_y = y - (m_CharacterScaleDelta / 8);
			view_item_preview.SetPos(new_x, new_y);
		}
	}

	void UpdateRotation(int mouse_x, int mouse_y, bool is_dragging)
	{
		vector o = m_CharacterOrientation;
		o[2] = o[2] + (m_CharacterRotationY - mouse_y);
		o[1] = o[1] - (m_CharacterRotationX - mouse_x);

		view_item_preview.SetModelOrientation(o);

		if (!is_dragging)
		{
			m_CharacterOrientation = o;
		}
	}

	void ResetPreview()
	{
		m_CurrentPreviewObject = NULL;
	}
	
	void UpdatePreview()
	{
		ErrorEx("", ErrorExSeverity.INFO);
		if (!m_P2PMarketMenu.GetSelectedPreviewObject())
			return;

		string previewClassName = GetPreviewClassName(m_P2PMarketMenu.GetSelectedPreviewObject().GetType());
		
		if (!UsePlayerPreview())
		{
			ErrorEx("Item Preview", ErrorExSeverity.INFO);
			view_item_preview.Show(true);
			view_player_preview.Show(false);
			m_P2PMarketMenuDetailsController.ViewItemPreview = m_P2PMarketMenu.GetSelectedPreviewObject();
			m_P2PMarketMenuDetailsController.NotifyPropertyChanged("ViewItemPreview");

			m_CurrentPreviewObject = m_P2PMarketMenu.GetSelectedPreviewObject();
		}
		else
		{
			ErrorEx("Player Preview", ErrorExSeverity.INFO);
			view_item_preview.Show(false);
			view_player_preview.Show(true);

			if (!m_PlayerPreview)
				m_PlayerPreview = new ExpansionPlayerPreview(this, view_player_preview);

			m_PlayerPreview.Update(previewClassName);
		}
	}
	
	override void ShowInfoButton(bool state)
	{
		info_content.Show(state);
	}

	override void UpdatePlayerPreviewObject(Object previewObject)
	{
		ErrorEx("Object: " + previewObject, ErrorExSeverity.INFO);

		m_P2PMarketMenuDetailsController.ViewPlayerPreview = previewObject;
		m_P2PMarketMenuDetailsController.NotifyPropertyChanged("ViewPlayerPreview");
	}

	override void SpawnPlayerPreviewAttachments(EntityAI item)
	{
		if (m_P2PMarketMenu.GetSelectedContainerItems().Count() > 0)
		{
			int skinIndex;
			ItemBase itemIB;
			if (Class.CastTo(itemIB, m_P2PMarketMenu.GetSelectedPreviewObject()))
				skinIndex = itemIB.ExpansionGetCurrentSkinIndex();

			SpawnAttachments(m_P2PMarketMenu.GetSelectedContainerItems(), item);
		}
	}

	override void SetCurrentPreviewObject(Object obj)
	{
		m_CurrentPreviewObject = obj;
	}

	ExpansionP2PMarketMenuDetailsViewController GetDetailsViewController()
	{
		return m_P2PMarketMenuDetailsController;
	}

	void OnBackClick()
	{
		m_P2PMarketMenu.OnBackClick();
	}

	int GetListPrice()
	{
		return m_ListPrice;
	}

	int GetListCost()
	{
		return m_ListCost;
	}

	void ShowItemQuantity(bool state)
	{
		item_quantity.Show(state);
		quantity_value.Show(state);
		
		if (state)
			quantity_value.SetColor(ARGB(255, 255, 255, 255));
	}
	
	void ShowQuantityBar(bool state)
	{
		item_quantity.Show(state);
		quantity_bar_panel.Show(state);
		quantity_bar.Show(state);
		quantity_value.Show(state);
		
		if (state)
			quantity_value.SetColor(ARGB(255, 0, 0, 0));
	}

	void ShowQuantityColor(bool state, int color = -1)
	{
		item_quantity.Show(state);
		quantity_bar_panel.Show(state);
		quantity_color.Show(state);
		quantity_value.Show(state);
		
		if (state)
		{
			quantity_value.SetColor(ARGB(255, 255, 255, 255));
			quantity_color.SetColor(color | 0x7F000000);
		}
	}

	void ShowItemLiquid(bool state)
	{
		item_liquid.Show(state);
	}
	
	void SetLiquidColor(int color)
	{
		liquid_color.SetColor(color | 0x7F000000);
	}

	void ShowItemCargoCount(bool state)
	{
		item_cargo_count.Show(state);
	}
	
	void ShowItemAttachmentsCount(bool state)
	{
		item_attachments_count.Show(state);
	}
	
	void ShowItemFoodState(bool state)
	{
		item_foodstate.Show(state);
	}
	
	void SetFoodStateColor(int color)
	{
		foodstate_color.SetColor(color | 0x7F000000);
	}
	
#ifdef EXPANSIONMODHARDLINE
	void ShowItemRarity(bool state)
	{
		item_rarity.Show(state);
	}
	
	void SetRarityColor(int color)
	{
		rarity_color.SetColor(color | 0x7F000000);
	}
	
	void SetRarityTextColor(int color)
	{
		rarity_value.SetColor(color | 0x7F000000);
	}
#endif
	
	void ShowConfirmButton(bool state)
	{
		confirm_button_panel.Show(state);
	}

	void ClearAttachments()
	{
		m_P2PMarketMenuDetailsController.AttachmentItems.Clear();
	}

	void AddAttachmentEntry(ExpansionP2PMarketMenuCargoItem attachment)
	{
		m_P2PMarketMenuDetailsController.AttachmentItems.Insert(attachment);
	}

	void ClearCargo()
	{
		m_P2PMarketMenuDetailsController.CargoItems.Clear();
	}

	void AddCargoEntry(ExpansionP2PMarketMenuCargoItem cargo)
	{
		m_P2PMarketMenuDetailsController.CargoItems.Insert(cargo);
	}

	void SetViewList()
	{
		price_text.Show(false);
		listing_price_editbox.Show(true);
		listing_cost_panel.Show(true);
		info_title.Show(true);
		info_grid.Show(true);
		item_description.Show(false);
		listing_lowest_panel.Show(true);
		listing_highest_panel.Show(true);
		if (GetExpansionSettings().GetMarket().MarketSystemEnabled)
			listing_market_panel.Show(true);
	}

	void SetViewListing()
	{
		price_text.Show(true);
		listing_price_editbox.Show(false);
		listing_cost_panel.Show(false);
		info_title.Show(false);
		info_grid.Show(false);
		item_description.Show(true);
		listing_lowest_panel.Show(false);
		listing_highest_panel.Show(false);
		listing_market_panel.Show(false);
	}
	
	void OnConfirmButtonClick()
	{
		m_P2PMarketMenu.OnConfirmButtonClick();
	}

	ProgressBarWidget GetQuantityBarWidget()
	{
		return quantity_bar;
	}

	EditBoxWidget GetEditBoxWidget()
	{
		return listing_price_editbox;
	}

	ImageWidget GetHealthImageWidget()
	{
		return health_image;
	}
	
	RichTextWidget GetItemDescriptionWidget()
	{
		return item_description;
	}
	
	ExpansionMarketMenuTooltip GetMarketPriceTooltip()
	{
		return m_MarketPriceTooltip;
	}
	
	override bool OnChange(Widget w, int x, int y, bool finished)
	{
		if (w != NULL && w == listing_price_editbox)
		{
			bool valid = true;
			string priceText = listing_price_editbox.GetText();

		#ifdef DIAG_DEVELOPER
			EXTrace.Print(EXTrace.P2PMARKET, this, "::OnChange - price text: " + priceText);
		#endif

			//! Convert localized input
			string thousandsSeparator = Widget.TranslateString("#STR_EXPANSION_NUMBER_SEPARATOR_THOUSANDS");
			if (thousandsSeparator)
				priceText.Replace(thousandsSeparator, "");
			string decimalSeparator = Widget.TranslateString("#STR_EXPANSION_NUMBER_SEPARATOR_DECIMAL");
			if (decimalSeparator)
				priceText.Replace(decimalSeparator, ".");
			priceText.Replace(" ", "");

		#ifdef DIAG_DEVELOPER
			EXTrace.Print(EXTrace.P2PMARKET, this, "::OnChange - price text after conversion of localized input: " + priceText);
		#endif

			float priceFloat = priceText.ToFloat();  //! Will be nan if not a valid number

		#ifdef DIAG_DEVELOPER
			EXTrace.Print(EXTrace.P2PMARKET, this, "::OnChange - price after conversion to float: " + priceFloat.ToString());
			if (priceFloat == "nan".ToFloat())
				EXTrace.Print(EXTrace.P2PMARKET, this, "::OnChange - price is nan");
		#endif

			string allowedCharacters = "0123456789.e";
			int pointCount;
			for (int i = 0; i < priceText.Length(); ++i)
			{
				string c = priceText[i];

				if (c == ".")
					pointCount++;

				if (allowedCharacters.IndexOf(c) == -1 || pointCount > 1 || (c == "e" && !priceFloat))
				{
					valid = false;
					break;
				}
			}

			if (valid)
			{
				int displayCurrencyValue = m_P2PMarketMenu.GetDisplayCurrencyValue();
				int price;

				if (displayCurrencyValue > 1)
					price = priceFloat * displayCurrencyValue;
				else
					price = priceText.ToInt();

				string listCostString;

				//! Valid input
				m_ListPrice = price;
				m_ListCost = Math.Ceil(price * ExpansionP2PMarketModule.GetModuleInstance().GetListingPricePercent(m_P2PMarketMenu.GetTraderID(), PlayerBase.Cast(g_Game.GetPlayer())) / 100);
				listCostString = m_P2PMarketMenu.GetDisplayPrice(m_ListCost, false, true, true);

			#ifdef DIAG_DEVELOPER
				EXTrace.Print(EXTrace.P2PMARKET, this, "::OnChange - valid price " + price);
			#endif
			}
			else
			{
				//! Invalid input
				m_ListPrice = -1;
				m_ListCost = -1;
				listCostString = "";
				listing_price_editbox.SetText("");
			#ifdef DIAG_DEVELOPER
				EXTrace.Print(EXTrace.P2PMARKET, this, "::OnChange - invalid price " + price);
			#endif
			}

			m_P2PMarketMenuDetailsController.ListCost = listCostString;
			m_P2PMarketMenuDetailsController.NotifyPropertyChanged("ListCost");
		}

		return false;
	}

	override bool OnMouseEnter(Widget w, int x, int y)
	{
		if (w != NULL)
		{
			if (w == back_button)
			{
				back_button.SetColor(ARGB(255, 255, 255, 255));
				back_button_text.SetColor(ARGB(255, 0, 0, 0));
				return true;
			}
			else if (w == confirm_button)
			{
				confirm_button.SetColor(ARGB(255, 255, 255, 255));
				confirm_button_text.SetColor(ARGB(255, 0, 0, 0));
				return true;
			}
			else if (w == listing_market_panel)
			{
				if (m_MarketPriceTooltip)
					m_MarketPriceTooltip.Show();
				
				return true;
			}
			else if (w == info_button)
			{
				m_InfoTooltip.Show(true);
				return true;
			}
		}

		return false;
	}

	override bool OnMouseLeave(Widget w, Widget enterW, int x, int y)
	{
		if (w != NULL)
		{
			if (w == back_button)
			{
				back_button.SetColor(ARGB(255, 0, 0, 0));
				back_button_text.SetColor(ARGB(255, 255, 255, 255));
				return true;
			}
			else if (w == confirm_button)
			{
				confirm_button.SetColor(ARGB(255, 0, 0, 0));
				confirm_button_text.SetColor(ARGB(255, 255, 255, 255));
				return true;
			}
			else if (w == listing_market_panel)
			{
				if (m_MarketPriceTooltip)
					m_MarketPriceTooltip.Hide();
				
				return true;
			}
			else if (w == info_button)
			{
				m_InfoTooltip.Show(false);
				return true;
			}
		}

		return false;
	}

	override bool OnMouseWheel(Widget w, int x, int y, int wheel)
	{
		if (w == view_item_preview)
		{
			g_Game.GetDragQueue().Call(this, "UpdateScale");
			m_CharacterScaleDelta = wheel;
		}
		else if (w == view_player_preview)
		{
			m_PlayerPreview.OnMouseWheel(w, x, y, wheel);
			m_CharacterScaleDelta = wheel;
		}

		return false;
	}

	override bool OnMouseButtonDown(Widget w, int x, int y, int button)
	{
		if (w == view_item_preview)
		{
			g_Game.GetDragQueue().Call(this, "UpdateRotation");
			GetMousePos(m_CharacterRotationX, m_CharacterRotationY);
			return true;
		}
		else if (w == view_player_preview)
		{
			m_PlayerPreview.OnMouseButtonDown(w, x, y, button);
			GetMousePos(m_CharacterRotationX, m_CharacterRotationY);
			return true;
		}

		return false;
	}

	override bool OnItemSelected(Widget w, int x, int y, int row, int column, int oldRow, int oldColumn)
	{
		float itemx, itemy;
		if (w == view_item_preview)
		{
			m_CharacterOrientation = vector.Zero;

			view_item_preview.SetModelPosition(Vector(0,0,0.5));
			view_item_preview.SetModelOrientation(m_CharacterOrientation);

			view_item_preview.GetPos(itemx, itemy);

			view_item_preview.SetSize(1.5, 1.5);

			// align to center
			view_item_preview.SetPos(-0.225, -0.225);
		}
		else if (w == view_player_preview)
		{
			m_CharacterOrientation = vector.Zero;

			m_PlayerPreview.OnItemSelected(w, x, y, row, column, oldRow, oldColumn);
		}

		return false;
	}
	
	override void OnShow()
	{
		super.OnShow();
		
		item_details_attachments_scroller.VScrollToPos01(0);
		item_details_cargo_scroller.VScrollToPos01(0);
	}

	override void OnHide()
	{
		super.OnHide();

		if (m_PlayerPreview)
			m_PlayerPreview = null;
	}
};

class ExpansionP2PMarketMenuDetailsViewController: ExpansionViewController
{
	Object ViewItemPreview;
	Object ViewPlayerPreview;
	string SelectedName;
	string PriceEditBox;
	string ListingPrice;
	string ListCost;
	string LowestPrice;
	string HighestPrice;
	string MarketPrice;
	string InfoTextOne;
	string InfoTextTwo;
	string InfoTextThree;
	string ItemDescription;
	string ItemQuantity;
	string QuantityText;
	string ItemCount;
	string CargoItemsCount;
	string AttachmentItemsCount;
	string ItemHealth;
	string LiquidType;
	string FoodState;
	string Rarity;
	string ConfirmButtonText;
	ref ObservableCollection<ref ExpansionP2PMarketMenuCargoItem> AttachmentItems = new ObservableCollection<ref ExpansionP2PMarketMenuCargoItem>(this);
	ref ObservableCollection<ref ExpansionP2PMarketMenuCargoItem> CargoItems = new ObservableCollection<ref ExpansionP2PMarketMenuCargoItem>(this);
};